package com.example.exams_

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*
import android.content.SharedPreferences

class AddWeather : AppCompatActivity() {
    private lateinit var tem: EditText
    private lateinit var date: EditText
    private lateinit var time_day: EditText
    private lateinit var save: Button
    private lateinit var list_b: Button
    lateinit var sw:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_weather)
        tem=findViewById(R.id.tem)
        date=findViewById(R.id.date)
        time_day=findViewById(R.id.time_day)
        save=findViewById(R.id.button_save)
        list_b=findViewById(R.id.button_list)
        sw=getPreferences(MODE_PRIVATE)
        save.setOnClickListener{
            if(tem.text.toString().isEmpty()) {
                val i = Toast.makeText(this, "Введите температуру", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()
            }
            if(date.text.toString().isEmpty()) {
                val i = Toast.makeText(this, "Введите дату", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()
            }
            if(time_day.text.toString().isEmpty()) {
                val i = Toast.makeText(this, "Введите времени суток", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()
            }
            if (tem.text.toString().isEmpty() || date.text.toString().isEmpty()|| time_day.text.toString().isEmpty()){
                val i = Toast.makeText(this, "Введите температуру, дату или времени суток", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()
            }

            else{
                val temperature = tem.text.toString()
                val dates = date.text.toString()
                val time = time_day.text.toString()
                val info_day = Info(temperature, dates, time)
                val info =SharedPreferencesHelper.loadInfo(this).toMutableList()
                info.add(info_day)
                SharedPreferencesHelper.saveInfo(this,info)
                val i = Toast.makeText(this, "Погода на день добавлена.", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()
                tem.text = null
                date.text=null
                time_day.text=null
            }
        }
        list_b.setOnClickListener{
            val intent = Intent(this, EditorWeather::class.java)
            startActivity(intent)
        }
    }
}