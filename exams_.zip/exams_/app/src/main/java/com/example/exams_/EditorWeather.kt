package com.example.exams_

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView

class EditorWeather : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var clear: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor_weather)
        clear = findViewById(R.id.delete)
        listView = findViewById(R.id.list_view)

        val tickets = SharedPreferencesHelper.loadInfo(this)
        val Info_days = tickets.map { "Температура воздуха:${it.temperature} - ${it.date} - Время суток:${it.time} " }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, Info_days)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        listView.adapter = adapter

        clear.setOnClickListener {
            SharedPreferencesHelper.clearInfo(this)
            adapter.clear()
            adapter.notifyDataSetChanged()
        }
    }

    fun newDay(){
        val intent = Intent(this, AddWeather::class.java)
        startActivity(intent)
    }
}
