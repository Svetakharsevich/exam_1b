package com.example.exams_

import android.content.Context
import com.google.gson.Gson

object SharedPreferencesHelper {
    private const val PREFS_NAME = "MyPrefsFile"
    private const val TICKETS_KEY = "Info"

    fun saveInfo(context: Context, tickets: List<Info>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(tickets)
        editor.putString(TICKETS_KEY, json)
        editor.apply()
    }
    fun loadInfo(context: Context): List<Info> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString(TICKETS_KEY, null)
        return if (json != null) {
            gson.fromJson(json, Array<Info>::class.java).toList()
        } else {
            emptyList()
        }
    }
    fun clearInfo(context: Context) {
        val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        preferences.edit().remove(TICKETS_KEY).apply()
    }
}