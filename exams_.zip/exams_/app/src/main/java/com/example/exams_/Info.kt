package com.example.exams_

import java.util.Date

data class Info(val temperature:String, val date: String, val time: String)